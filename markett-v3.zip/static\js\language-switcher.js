/**
 * Fast Language Switcher - Simple and reliable
 * Direct form submission without JavaScript interference
 */

// This file is intentionally minimal to avoid conflicts
// The language switcher works natively through form submission
